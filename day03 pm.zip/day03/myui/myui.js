jQuery.fn.accordion=function(){
  //this->$("#my-accordion")
  var $parent=this;
  //侵入class和自定义扩展属性: 
  $parent
    .addClass("accordion")//return $parent
    .children(":even") //div title
    .addClass("title") //return div title
    .next() //div content
    .addClass("content fade")
    //return div content
    .first() //=>:first
    .addClass("in")

  //查找触发事件的元素，绑定事件
  $parent.on("click",".title",e=>
    $(e.target).next(".content").toggleClass("in")
      .siblings(".content").removeClass("in")
  );
}
//$("#my-accordion").accordion();